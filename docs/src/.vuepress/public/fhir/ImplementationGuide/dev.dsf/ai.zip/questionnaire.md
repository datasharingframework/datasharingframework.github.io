# Questionnaire - Data Sharing Framework (DSF) Implementation Guide v2.0.0

* [**Table of Contents**](toc.md)
* **Questionnaire**

## Questionnaire

[Questionnaire](https://www.hl7.org/fhir/R4/questionnaire.html) and [QuestionnaireResponse](https://www.hl7.org/fhir/R4/questionnaireresponse.html) resources are used by the DSF to implement the user interaction required in User Tasks.

