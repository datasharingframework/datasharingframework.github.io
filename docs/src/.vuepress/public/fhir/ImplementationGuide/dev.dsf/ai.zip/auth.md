# Auth - Data Sharing Framework (DSF) Implementation Guide v2.0.0

* [**Table of Contents**](toc.md)
* **Auth**

## Auth

* [Allowlist](./allowlist.md)
* [ActivityDefinition](./activitydefinition.md)
* [Read Access Tag](./readaccess.md)

