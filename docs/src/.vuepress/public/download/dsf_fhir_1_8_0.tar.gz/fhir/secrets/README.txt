Modify with generated password:

db_liquibase.password -> recomended min. 32 characters
db_user.password -> recomended min. 16 characters
db_user_permanent_delete.password -> recommended min. 16 characters


Add files (chmod: 440, chown: fhir:docker):

ssl_certificate_file.pem -> Server certificate file from D-TRUST, GÈANT TCS or HARICA (DFN)
ssl_certificate_chain_file.pem -> Server certificate CA chain (all certificates between server and root, excluding root), optional if part of ssl_certificate_file.pem
ssl_certificate_key_file.pem -> Server certificate private-key (unencrypted)
client_certificate.pem -> Client certificate file from D-TRUST, GÈANT TCS or HARICA (DFN)
client_certificate_private_key.pem -> Client certificate private-key (can be encrypted)
client_certificate_private_key.pem.password -> File with password for client certificate private-key (ommit file if not encrypted, remove corresponding entries from docker-compose -> lines 39,56,136,137)


Add other certificates, keys or passwords in the same way using docker secrets