Modify with generated password:

db_liquibase.password -> recomended min. 32 characters
db_user.password -> recomended min. 16 characters
db_user_camunda.password -> recommended min. 16 characters


Add files for DSF BPE server (chmod: 440, chown: root:2202):

client_certificate.pem -> Client certificate file from D-TRUST or HARICA (DFN)
client_certificate_private_key.pem -> Client certificate private-key (can be encrypted)
client_certificate_private_key.pem.password -> File with password for client certificate private-key (ommit file if not encrypted, remove corresponding entries from docker-compose -> lines 12,32,83,84)


Add other certificates, keys or passwords in the same way using docker secrets