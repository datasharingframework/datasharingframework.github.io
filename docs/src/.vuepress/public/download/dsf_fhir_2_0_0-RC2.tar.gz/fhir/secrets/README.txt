Modify with generated password:

db_liquibase.password -> recomended min. 32 characters
db_user.password -> recomended min. 16 characters
db_user_permanent_delete.password -> recommended min. 16 characters


Add files for DSF FHIR reverse proxy (chmod: 440, chown: root:4101):

ssl_certificate_file.pem -> Server certificate file from D-TRUST or HARICA (DFN)
ssl_certificate_chain_file.pem -> Server certificate CA chain (all certificates between server and root, excluding root), optional if part of ssl_certificate_file.pem
ssl_certificate_key_file.pem -> Server certificate private-key (unencrypted)


Add files for DSF FHIR server (chmod: 440, chown: root:2101):

client_certificate.pem -> Client certificate file from D-TRUST or HARICA (DFN)
client_certificate_private_key.pem -> Client certificate private-key (can be encrypted)
client_certificate_private_key.pem.password -> File with password for client certificate private-key (ommit file if not encrypted, remove corresponding entries from docker-compose -> lines 34,47,109,110)


Add other certificates, keys or passwords in the same way using docker secrets